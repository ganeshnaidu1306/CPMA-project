
let bt1 = document.getElementById("bt1");
let t1 = document.getElementById("t2");
let t2 = document.getElementById("t1");
let s1 = document.getElementById("s1");
let i1 = document.getElementById("img");
let c = document.getElementById("t3");
bt1.addEventListener("click",fun);

function fun() {
  if (t1.value === "") {
      
      alert("Enter a value");
      
  }
    
    else {
        if(s1.value == "o1")
            {
                let searchLink = "https://free.currencyconverterapi.com/api/v6/convert?q=USD_INR&compact=y";
                i1.src = "img/dollar.jpg";
                c.value = "Country: United States";
    
                httpRequestAsync(searchLink, theResponse);
            }
        
        if(s1.value == "o2")
            {
                let searchLink = "https://free.currencyconverterapi.com/api/v6/convert?q=EUR_INR&compact=y";
                i1.src = "img/euro.jpg";
                c.value = "Country: Europe";
                
                httpRequestAsync(searchLink, theResponse);            
            }   
        if(s1.value == "o3")
            {
                    let searchLink = "https://free.currencyconverterapi.com/api/v6/convert?q=KWD_INR&compact=y";
                    i1.src = "img/dinnar.jpg";
                    c.value = "Country: Kuwait";

                httpRequestAsync(searchLink, theResponse);
            }
  }
 }

function theResponse(response) {
    
    let jsonobject = JSON.parse(response);
    if(s1.value == "o1")
    {
        t2.value = parseFloat(jsonobject.USD_INR.val * t1.value)+" INR";
    }
    
    if(s1.value == "o2")
    {
        t2.value = parseFloat(jsonobject.EUR_INR.val * t1.value)+" INR";
    }
        
    if(s1.value == "o3")
    {
        t2.value = parseFloat(jsonobject.KWD_INR.val * t1.value)+" INR";
    }
}

function httpRequestAsync(url, callback)
{
  console.log("hello");
    var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = () => { 
        if (httpRequest.readyState == 4 && httpRequest.status == 200)
            callback(httpRequest.responseText);
    }
    httpRequest.open("GET", url, true); // true for asynchronous 
    httpRequest.send();
}